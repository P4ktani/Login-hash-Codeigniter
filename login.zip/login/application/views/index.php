<h3>Welcome <strong><?php echo $this->session->userdata('first_name');?></strong></h3>

<p>Your are now inside the application</p></br>
<a href="<?php echo base_url('main/logout')?>">Logout</a>
